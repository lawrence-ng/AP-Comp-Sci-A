
import java.awt.*;
import java.awt.Graphics;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.lang.*;

public class Sun extends Head
{
    private Color sunColor = new Color(252, 251, 50);
    private int degrees;
     private int width;    
   private int height;
    public Sun(int w,int h,int d){
        super(w,h);
        degrees = d;
          width = w;
      height = h;
    }
    @Override
    public void draw(Graphics g)
  {
      
      Graphics2D g2 = (Graphics2D) g;
      
    int radius = width/2-width/2*11/12;
    
    g2.setColor(sunColor);
    g2.fillArc(10,10,radius*8,radius*8,0,360);
    g2.setColor(Color.WHITE);
    
    
  } 
}
