
/**
 * Write a description of class PollTest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PollTest
{
    public static void main(String[] args)
    {
        
    }
}
