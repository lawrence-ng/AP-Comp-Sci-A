
/**
 * Write a description of class BankAcct here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BankAcct
{
    //FIELDS
    private double balance;
    
    //CONSTRUCTORS
    public BankAcct()
    {
        balance = 0.0;
    }
    
    public BankAcct(double initBal)
    {
        balance = initBal;
    }
    
    //METHODS
    public double getBalance()
    {
        return balance;
    }
    
    public void deposit(double amt)
    {
        balance += amt;
    }
    
    public void withdraw(double amt)
    {
        balance -= amt;
    }
    
    public void addInterest(double rate)
    {
        balance += balance * rate;
    }
}
